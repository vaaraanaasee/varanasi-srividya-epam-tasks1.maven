# epam-tasks1

# Java objects file is for object models

It contains classes(abstract classes),inheritance,encapsulation,polymorphism,interface.

It also takes user input also.

# newyeargift file is for epam task1(MAVEN project)
Problem Statement:New Year's gift. Identify the hierarchy of chocolates and other sweets. Create multiple objects of sweets. Collect children's gift to define total weight. Sort the chocolates in a gift by one of the options. Find candies in the gift corresponding to a predetermined range of options. 

Solution:first,it shows collection of chocolates and other sweets which are available.

It takes user input to select the chocolates and other sweets and calculates total weight for that.

It also calculates candies for the gift.

Test cases also been created for this project
